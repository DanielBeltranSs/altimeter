#pragma once

// ESP32-S3 Tiny SuperMini (según tu mapeo)
static constexpr int PIN_I2C_SDA = 6;   // GP6
static constexpr int PIN_I2C_SCL = 5;   // GP5
static constexpr uint32_t I2C_HZ   = 400000;

// Dirección típica del BMP390L (0x77 si SDO=VDD, 0x76 si SDO=GND)
static constexpr uint8_t BMP3_ADDR_DEFAULT = 0x77;

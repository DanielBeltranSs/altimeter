#include <Arduino.h>
#include <Wire.h>
#include "board_pins.h"
#include "drivers/bmp390_bosch.h"
#include "services/altitude_estimator.h"

// Ahorro energético (sleep) y apagar radios en suelo
#include "esp_sleep.h"
#if __has_include(<esp_wifi.h>)
  #include <esp_wifi.h>
#endif
#if __has_include(<esp_bt.h>)
  #include <esp_bt.h>
#endif

BMP390Bosch        bmp390;
AltitudeEstimator  alt;

// Perfil "suelo" a 1 s con modo FORCED del BMP390
static constexpr uint32_t GROUND_PERIOD_MS     = 1000; // 1 s exacto
static constexpr uint16_t FORCED_MEAS_WAIT_MS  = 30;   // margen para conversión (OSR bajos)

static float calibrateSeaLevelPa(int samples = 50, uint16_t delayMs = 20) {
  Serial.printf("Calibrando p0 con %d muestras...\n", samples);
  double sum = 0.0;
  float p, t;
  int ok = 0;
  for (int i = 0; i < samples; ++i) {
    // En FORCED debemos disparar cada lectura
    bmp390.triggerForcedMeasurement();
    delay(FORCED_MEAS_WAIT_MS);
    if (bmp390.read(p, t)) { sum += p; ++ok; }
    delay(delayMs);
  }
  if (ok == 0) return 101325.0f; // fallback
  float p0 = static_cast<float>(sum / ok);
  Serial.printf("p0 = %.2f Pa (%d muestras válidas)\n", p0, ok);
  return p0;
}

void setup() {
  Serial.begin(115200);
#if ARDUINO_USB_CDC_ON_BOOT
  // Espera breve a que el puerto CDC esté listo (USB nativo en S3)
  for (int i = 0; i < 150 && !Serial; ++i) { delay(10); }
#endif
  delay(50);
  Serial.println("\n=== Altímetro BMP390L (API Bosch) - ESP32-S3 ===");

  // Init I2C with board-defined pins and speed
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, I2C_HZ);

  // Suelo: baja frecuencia de CPU y radios apagadas
#if defined(ARDUINO_ARCH_ESP32)
  setCpuFrequencyMhz(80);
#endif
#if __has_include(<esp_wifi.h>)
  esp_wifi_stop();
#endif
#if __has_include(<esp_bt.h>)
  esp_bt_controller_disable();
#endif

  if (!bmp390.begin(Wire, BMP3_ADDR_DEFAULT, I2C_HZ)) {
    Serial.println("ERROR: No se pudo inicializar el BMP390L (revise I2C/dir 0x76/0x77).");
    while (true) delay(1000);
  }

  uint8_t id = 0;
  if (bmp390.whoAmI(id)) {
    Serial.printf("Chip ID: 0x%02X\n", id);
  }

  // Suelo a 1 s: FORCED => el sensor duerme entre mediciones
  if (!bmp390.setForcedMode(
        BMP3_OVERSAMPLING_2X,     // presión 1X (rápido y suficiente en suelo)
        BMP3_NO_OVERSAMPLING,     // temperatura 1X
        BMP3_IIR_FILTER_COEFF_1)) // filtro suave
  {
    Serial.printf("ERROR: setForcedMode() falló. lastError=%d\n", bmp390.lastError());
    while (true) delay(1000);
  }

  // Suavizado ligero para salida estable
  alt.setEmaAlpha(0.25f);
  alt.setSeaLevelPressure(calibrateSeaLevelPa());

  Serial.println("Imprimiendo: alt_m | presion_Pa | temp_C");
}

void loop() {
  // 1) Dispara una conversión FORCED
  bmp390.triggerForcedMeasurement();
  delay(FORCED_MEAS_WAIT_MS);

  // 2) Lee resultado
  float p, t;
  if (bmp390.read(p, t)) {
    const float altRaw = alt.toAltitudeMeters(p);
    const float altSm  = alt.filter(altRaw);
    Serial.printf("%.2f m | %.2f Pa | %.2f C\n", altSm, p, t);
  } else {
    Serial.printf("Lectura fallida (err=%d)\n", bmp390.lastError());
  }

  // 3) Light-sleep hasta completar el periodo de 1 s
  const uint32_t remain = (GROUND_PERIOD_MS > FORCED_MEAS_WAIT_MS)
                          ? (GROUND_PERIOD_MS - FORCED_MEAS_WAIT_MS)
                          : 1;
  Serial.flush();
  esp_sleep_enable_timer_wakeup((uint64_t)remain * 1000ULL);
  esp_light_sleep_start();
}

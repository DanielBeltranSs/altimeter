#include "flight_mode.h"
#include <math.h>

void FlightModeDetector::begin(float ground_alt_m, const FlightModeConfig& cfg) {
  _cfg = cfg;
  _ground_alt = ground_alt_m;
  _prev_alt = ground_alt_m;
  _prev_ms = 0;
  _enter_ts = 0;
  _mode = FlightMode::GROUND;
  _vz_ema = 0.0f;
}

FlightMode FlightModeDetector::update(float alt_m, uint32_t now_ms) {
  if (_prev_ms == 0) { // primera muestra
    _prev_ms = now_ms;
    _prev_alt = alt_m;
    _enter_ts = now_ms;
    return _mode;
  }

  const float dt = (now_ms - _prev_ms) / 1000.0f;
  float vz = 0.0f;
  if (dt > 0.0f) vz = (alt_m - _prev_alt) / dt;

  // EMA sobre vz
  _vz_ema = _cfg.vz_alpha * vz + (1.0f - _cfg.vz_alpha) * _vz_ema;

  // Altitud AGL
  const float agl = alt_m - _ground_alt;

  // Transiciones con histéresis + dwell
  switch (_mode) {
    case FlightMode::GROUND: {
      if (_vz_ema > _cfg.climb_vz_enter && dwellOK(now_ms, _cfg.min_dwell_ground)) {
        _mode = FlightMode::CLIMB;
        _enter_ts = now_ms;
      }
      break;
    }
    case FlightMode::CLIMB: {
      if (_vz_ema < _cfg.ff_vz_enter && dwellOK(now_ms, _cfg.min_dwell_climb)) {
        _mode = FlightMode::FREEFALL;
        _enter_ts = now_ms;
      } else if (_vz_ema < _cfg.climb_vz_exit && dwellOK(now_ms, _cfg.min_dwell_climb)) {
        // cayó actividad -> vuelve a GROUND (ej. aún en tierra)
        _mode = FlightMode::GROUND;
        _enter_ts = now_ms;
      }
      break;
    }
    case FlightMode::FREEFALL: {
      // Salida a CANOPY cuando frena significativamente y estamos a altura razonable
      if (_vz_ema > _cfg.canopy_vz_enter && agl > _cfg.canopy_min_alt_agl &&
          dwellOK(now_ms, _cfg.min_dwell_ff)) {
        _mode = FlightMode::CANOPY;
        _enter_ts = now_ms;
      }
      break;
    }
    case FlightMode::CANOPY: {
      // Si vuelve a caer fuerte, regresa a FF; si calma mucho y baja vz, puede volver a CLIMB/GROUND
      if (_vz_ema < _cfg.canopy_vz_exit && dwellOK(now_ms, _cfg.min_dwell_canopy)) {
        _mode = FlightMode::FREEFALL;
        _enter_ts = now_ms;
      } else if (fabsf(_vz_ema) < _cfg.climb_vz_exit && dwellOK(now_ms, _cfg.min_dwell_canopy)) {
        // muy estable -> probablemente taxi/aterrizado
        _mode = FlightMode::GROUND;
        _enter_ts = now_ms;
      }
      break;
    }
  }

  _prev_alt = alt_m;
  _prev_ms = now_ms;
  return _mode;
}

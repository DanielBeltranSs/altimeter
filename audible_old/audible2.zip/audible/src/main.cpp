#include <Arduino.h>
#include <Wire.h>
#include "board_pins.h"

#include "drivers/bmp390_bosch.h"
#include "services/altitude_estimator.h"
#include "services/auto_ground_zero.h"
#include "drivers/button.h"
#include "services/display_mgr.h"
#include "services/ble_manager.h"
#include "app/flight_mode.h"
#include "services/sensor_profile.h"
#include "drivers/buzzer.h"          // ← NUEVO

#include "esp_sleep.h"
#if __has_include(<esp_wifi.h>)
  #include <esp_wifi.h>
#endif
#if __has_include(<esp_bt.h>)
  #include <esp_bt.h>
#endif

// ==== Unidades / Config ====
static constexpr float M2FT = 3.280839895f;
static constexpr uint32_t OLED_BUMP_MINUTES = 2;
static constexpr uint32_t OLED_BUMP_MAX_MIN = 10;
static constexpr uint16_t FORCED_WAIT_MS = 25;
static constexpr uint32_t BLE_WINDOW_MS = 120000;
static constexpr uint32_t BLE_DISC_GRACE_MS = 10000;

// ==== Objetos globales ====
static BMP390Bosch        gBmp;
static AltitudeEstimator  gAlt;
static AutoGroundZero     gAgz;
static FlightModeDetector gFsm;
static FlightMode         gMode = FlightMode::GROUND;
static Button             gBtn;
#ifdef ENABLE_DISPLAY
static DisplayMgr         gDisp;
#endif
static BleManager         gBle;
static SensorProfile      gProf;
static Buzzer             gBuzz;      // ← NUEVO

// Loop timing
static uint32_t gLoopPeriodMs = 1000;
static bool     gNormalStreaming = false;

// --- Helpers ---
static float calibrateP0() {
  Serial.printf("Calibrando p0...\n");
  double acc=0; int ok=0;
  float p,t;
  gBmp.setForcedMode(BMP3_OVERSAMPLING_2X, BMP3_NO_OVERSAMPLING, BMP3_IIR_FILTER_COEFF_1);
  for (int i=0;i<50;++i){
    gBmp.triggerForcedMeasurement(); delay(FORCED_WAIT_MS);
    if (gBmp.read(p,t)){ acc+=p; ++ok; }
    delay(20);
  }
  float p0 = ok ? static_cast<float>(acc/ok) : 101325.0f;
  Serial.printf("p0=%.2f Pa (%d)\n", p0, ok);
  return p0;
}

static void handleButton(BtnEvent ev, uint32_t now) {
  switch (ev) {
    case BtnEvent::Short:
#ifdef ENABLE_DISPLAY
      gDisp.on();
      gDisp.bumpMinutes(OLED_BUMP_MINUTES, OLED_BUMP_MAX_MIN);
      gDisp.showStatus("DISPLAY", "ACTIVE");
#endif
      break;

    case BtnEvent::Long3:
      if (gMode == FlightMode::GROUND) {
        // Zero rápido a presión actual (promedio corto)
        double acc=0; int ok=0; float p,t;
        for (int i=0;i<10;++i){
          gBmp.triggerForcedMeasurement(); delay(FORCED_WAIT_MS);
          if (gBmp.read(p,t)) { acc+=p; ++ok; }
          delay(10);
        }
        if (ok){
          float p0 = static_cast<float>(acc/ok);
          gAlt.setSeaLevelPressure(p0);
          gAgz.begin(p0);
          Serial.printf("ZERO OK p0=%.2f Pa\n", p0);
#ifdef ENABLE_DISPLAY
          if (gDisp.isOn()) gDisp.showStatus("0", "OK");  // ← “0 OK”
#endif
          gBuzz.playCalibrationOk();                       // ← sonido
        } else {
          Serial.println("ZERO FAIL");
#ifdef ENABLE_DISPLAY
          if (gDisp.isOn()) gDisp.showStatus("ZERO", "FAIL");
#endif
        }
      } else {
        Serial.println("ZERO DENIED: not GROUND");
#ifdef ENABLE_DISPLAY
        if (gDisp.isOn()) gDisp.showStatus("DENIED", "NOT GROUND");
#endif
      }
      break;

    case BtnEvent::Long8:
      if (gMode == FlightMode::GROUND) {
        gBle.enable(now, BLE_WINDOW_MS);
#ifdef ENABLE_DISPLAY
        if (gDisp.isOn()) gDisp.showStatus("BLE", "ENABLED 2m");
        gDisp.setBleIndicator(true);                       // ← enciende indicador “B”
#endif
        gBuzz.playBleEnabled();                            // ← sonido
      } else {
        Serial.println("BLE DENIED: not GROUND");
#ifdef ENABLE_DISPLAY
        if (gDisp.isOn()) gDisp.showStatus("DENIED", "NOT GROUND");
#endif
      }
      break;

    case BtnEvent::None:
    default: break;
  }
}

// Decide si usar light sleep con botón
static inline bool canSleepLight() {
#ifdef ENABLE_DISPLAY
  if (gDisp.isOn()) return false;
#endif
  return true;
}

void setup() {
  Serial.begin(115200);
#if ARDUINO_USB_CDC_ON_BOOT
  for (int i=0;i<150 && !Serial; ++i) delay(10);
#endif

  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, I2C_HZ);

#if defined(ARDUINO_ARCH_ESP32)
  setCpuFrequencyMhz(80);
#endif
#if __has_include(<esp_wifi.h>)
  esp_wifi_stop();
#endif
#if __has_include(<esp_bt.h>)
  esp_bt_controller_disable();
#endif

  // Botón
  gBtn.begin(PIN_BUTTON, true);
  gBtn.setTimings(30, 250, 2500, 8000);
  gBtn.enableGpioWakeForLightSleep();

  // Buzzer
  gBuzz.begin(PIN_BUZZER, /*active_high=*/true);

  // Pantalla
#ifdef ENABLE_DISPLAY
  gDisp.begin(OLED_I2C_ADDR, I2C_HZ);
  gDisp.on(); gDisp.showStatus("BOOT","OLED TEST"); delay(1000); gDisp.off();
#endif

  // Sensor
  if (!gBmp.begin(Wire, BMP3_ADDR_DEFAULT, I2C_HZ)) {
    Serial.println("ERROR: BMP390 init");
#ifdef ENABLE_DISPLAY
    gDisp.on(); gDisp.showStatus("BMP ERROR","Check I2C");
#endif
    while(true) delay(1000);
  }

  // Estimador y p0
  gAlt.setEmaAlpha(0.25f);
  float p0 = calibrateP0();
  gAlt.setSeaLevelPressure(p0);
  gAgz.begin(p0);

  // Perfiles iniciales
  gProf.applyFor(FlightMode::GROUND, gBmp, gLoopPeriodMs, gNormalStreaming);

  // FSM seed
  float p,t;
  if (gBmp.read(p,t)) gFsm.begin(gAlt.filter(gAlt.toAltitudeMeters(p)));
  else                gFsm.begin(0.0f);

  Serial.println("mode | alt_ft | P(Pa) | T(C)");
}

void loop() {
  const uint32_t now = millis();

  // 1) Botón en activo
  if (BtnEvent ev = gBtn.poll(now); ev != BtnEvent::None) handleButton(ev, now);

  // 2) Lectura baro
  float p=NAN, t=NAN;
  if (gNormalStreaming) {
    gBmp.read(p, t);
  } else {
    gBmp.triggerForcedMeasurement();
    delay(FORCED_WAIT_MS);
    gBmp.read(p, t);
  }

  if (!isnan(p)) {
    const float alt_m  = gAlt.toAltitudeMeters(p);
    const float alt_sm = gAlt.filter(alt_m);

    if (gAgz.update(p, alt_sm, gMode, now)) {
      gAlt.setSeaLevelPressure(gAgz.p0());
      Serial.printf("AGZ p0=%.2f Pa\n", gAgz.p0());
    }

    FlightMode newMode = gFsm.update(alt_sm, now);
    if (newMode != gMode) {
      gMode = newMode;
      gProf.applyFor(gMode, gBmp, gLoopPeriodMs, gNormalStreaming);
      if (gMode != FlightMode::GROUND) gBle.disable();
    }

#ifdef ENABLE_DISPLAY
    // Indicador BLE parpadeante según estado real
    gDisp.setBleIndicator(gBle.(gBle, 0));

    if (gDisp.isOn()) gDisp.showAltitude(alt_sm,
      (gMode==FlightMode::FREEFALL?"FREEFALL": gMode==FlightMode::CLIMB?"CLIMB":
       gMode==FlightMode::CANOPY?"CANOPY":"GROUND"));
#endif

    Serial.printf("%d | %.1f | %.2f | %.2f\n",
      (int)gMode, alt_sm * M2FT, p, t);
  } else {
    Serial.printf("Read FAIL (err=%d)\n", gBmp.lastError());
#ifdef ENABLE_DISPLAY
    if (gDisp.isOn()) gDisp.showStatus("SENSOR","READ FAIL");
#endif
  }

  // 3) Servicios
#ifdef ENABLE_DISPLAY
  gDisp.tick(now);
#endif
  gBle.tick(now, /*must_off*/ gMode != FlightMode::GROUND);

  // 4) Sleep
  Serial.flush();
  if (canSleepLight()) {
    BtnEvent wakeEv = gBtn.lightSleepWaitAndClassify((uint64_t)gLoopPeriodMs * 1000ULL);
    if (wakeEv != BtnEvent::None) handleButton(wakeEv, millis());
  } else {
    esp_sleep_enable_timer_wakeup((uint64_t)gLoopPeriodMs * 1000ULL);
    esp_light_sleep_start();
  }
}

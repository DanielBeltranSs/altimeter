#pragma once
#include <stdint.h>
#include <math.h>
#include "app/flight_mode.h"

struct AutoGZConfig {
  // Ventana/estabilidad
  float alt_sigma_thresh_m = 0.30f;   // desviación estándar máx (m) para considerar estable
  float alt_abs_thresh_m   = 3.0f;    // altitud absoluta permitida para auto-zero
  uint32_t stable_time_ms  = 15000;   // tiempo continuo en GROUND estable antes de ajustar
  uint32_t min_interval_ms = 60000;   // tiempo mínimo entre ajustes sucesivos

  // Promedios (EMA)
  float alpha_alt   = 0.10f;          // EMA para altitud
  float alpha_alt2  = 0.10f;          // EMA para alt^2
  float alpha_press = 0.10f;          // EMA para presión

  // Límite de paso de p0 por ajuste (en Pa). 1 Pa ≈ 0.084 m.
  float max_step_pa = 0.8f;           // ≈ 7 cm por ajuste
};

class AutoGroundZero {
public:
  void begin(float p0_init, const AutoGZConfig& cfg = AutoGZConfig()) {
    _cfg = cfg; _p0 = p0_init;
    _ema_alt = 0.0f; _ema_alt2 = 0.0f; _ema_p = p0_init;
    _last_apply_ms = 0; _stable_enter_ms = 0; _have_sample = false;
  }

  // Devuelve true si _p0 fue actualizado en esta llamada
  bool update(float pressurePa, float alt_m, FlightMode mode, uint32_t now_ms) {
    // Sólo auto-zero en GROUND
    if (mode != FlightMode::GROUND) {
      _stable_enter_ms = 0;
      _have_sample = false;
      return false;
    }
    // Actualiza EMAs
    if (!_have_sample) {
      _ema_alt = alt_m; _ema_alt2 = alt_m * alt_m; _ema_p = pressurePa; _have_sample = true;
    } else {
      _ema_alt   = _cfg.alpha_alt   * alt_m           + (1.0f - _cfg.alpha_alt)   * _ema_alt;
      _ema_alt2  = _cfg.alpha_alt2  * (alt_m * alt_m) + (1.0f - _cfg.alpha_alt2)  * _ema_alt2;
      _ema_p     = _cfg.alpha_press * pressurePa      + (1.0f - _cfg.alpha_press) * _ema_p;
    }

    // Estabilidad por varianza y proximidad a cero
    const float var = fmaxf(0.0f, _ema_alt2 - _ema_alt * _ema_alt);
    const float sigma = sqrtf(var);
    const bool near_zero   = fabsf(_ema_alt) <= _cfg.alt_abs_thresh_m;
    const bool low_noise   = sigma <= _cfg.alt_sigma_thresh_m;

    if (near_zero && low_noise) {
      if (_stable_enter_ms == 0) _stable_enter_ms = now_ms;
    } else {
      _stable_enter_ms = 0;
      return false;
    }

    // ¿toca aplicar?
    const bool time_ok = (now_ms - _stable_enter_ms) >= _cfg.stable_time_ms;
    const bool spacing_ok = (now_ms - _last_apply_ms) >= _cfg.min_interval_ms;
    if (time_ok && spacing_ok) {
      // Objetivo: que alt=0 ⇒ con la fórmula ISA, p0 ≈ presión local cuando alt≈0
      const float p0_target = _ema_p;

      // Paso limitado en Pa
      float delta = p0_target - _p0;
      if (delta >  _cfg.max_step_pa) delta =  _cfg.max_step_pa;
      if (delta < -_cfg.max_step_pa) delta = -_cfg.max_step_pa;

      if (fabsf(delta) > 0.0001f) {   // evita trabajo innecesario
        _p0 += delta;
        _last_apply_ms = now_ms;
        return true;
      }
    }
    return false;
  }

  float p0() const { return _p0; }

private:
  AutoGZConfig _cfg{};
  float _p0 = 101325.0f;
  float _ema_alt = 0.0f, _ema_alt2 = 0.0f, _ema_p = 101325.0f;
  uint32_t _last_apply_ms = 0;
  uint32_t _stable_enter_ms = 0;
  bool _have_sample = false;
};
